import React from 'react'
import { Box } from '@mui/system'

const Home = ({value, onChange}) => {
    return (
        <Box className='home'>
        
        </Box>
    )
}

export default Home